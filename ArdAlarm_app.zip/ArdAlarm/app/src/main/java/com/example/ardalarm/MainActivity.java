package com.example.ardalarm;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

//MainActivity contains the driver code for the ArdAlarm application
public class MainActivity extends AppCompatActivity{
    //Define all necessary objects for the application
    private Button arm, disarm, send, set;
    private EditText password, newCode;
    private BluetoothAdapter bta;
    private BluetoothDevice ard;
    private static final UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //represent the uuid of the bluetooth module (same for all bluetooth modules)
    private static BluetoothSocket socket = null;
    private int attempts;
    private OutputStream out;

    /*
     * onCreate() is run when the main screen for the app is displayed.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arm = findViewById(R.id.arm); //Button to send arm signal to Arduino
        disarm = findViewById(R.id.disarm); //Button to send disarm signal to Arduino
        send = findViewById(R.id.send); //Button to send password to Arduino
        set = findViewById(R.id.set); //Button to set a new password on the Arduino
        password = findViewById(R.id.editTextTextPassword); //Input field to enter desired password to send
        newCode = findViewById(R.id.setPassword); //Input field to enter desired new password to set

        bta = BluetoothAdapter.getDefaultAdapter();
        ard = bta.getRemoteDevice("00:14:03:05:09:CF"); //contains mac address of arduino bt module
        //Note: the address will need to be changed to match your specific HC-05's mac address

        System.out.println(bta.getBondedDevices()); //test bluetooth connection
        System.out.println(ard.getName());

        //allow the bluetooth socket 5 attempts to establish a successful connection
        attempts = 0;
        do { //attempt to establish socket connection
            try {
                socket = ard.createInsecureRfcommSocketToServiceRecord(uuid);
                socket.connect();

                System.out.println(socket); //test socket connection
                System.out.println(socket.isConnected());
            } catch (IOException e) {
                e.printStackTrace();
            }

            attempts++;
        } while(!socket.isConnected() && attempts < 5);

        //initialize output stream to write messages to the Arduino
        try {
            out = socket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        bta.cancelDiscovery(); //have the BluetoothAdapter stop searching for devices to increase socket communication speed

        /*
         * OnClickListeners wait for a button to be pressed on the UI.
         * It will then carry out a specific action depending on the button that was pressed.
         */
        /*
         * The arm OnClickListener sends the byte 49 (ASCII code for '0') to the alarm.
         * This will set the system to an armed state.
         * Also displays a popup message on the app confirming the message was sent.
         */
        arm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    out.write(49);
                }catch (IOException e){
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(), "System Armed", Toast.LENGTH_LONG).show();
            }
        });
        /*
         * The disarm OnClickListener sends the byte 500 (ASCII code for '1') to the alarm.
         * This will set the system to a disarmed state (assuming the alarm is not waiting for a password).
         * Also displays a popup message on the app confirming the message was sent.
         */
        disarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    out.write(48);
                }catch (IOException e){
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(), "System Disarmed", Toast.LENGTH_LONG).show();
            }
        });
        /*
         * The send OnClickListener sends a byte array containing '*' (the password marker)
         * followed by the text input by the user into the password text field.
         * This will be processed by the Arduino as a password attempt and will deactivate the alarm if correct.
         * If incorrect, a message will be displayed by the Arduino.
         * Also displays a popup message on the app confirming the message was sent.
         */
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(password.getText().length() == 0)
                    Toast.makeText(getApplicationContext(), "Please Enter Password", Toast.LENGTH_LONG).show();
                else {
                    String msg = "*" + password.getText().toString();
                    byte[] msgBytes = msg.getBytes();

                    try {
                        out.write(msgBytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getApplicationContext(), "Password Sent", Toast.LENGTH_LONG).show();
                }
                //minimizes keyboard upon message being sent
                password.getText().clear();
                password.onEditorAction(EditorInfo.IME_ACTION_DONE);
                newCode.onEditorAction(EditorInfo.IME_ACTION_DONE);
            }
        });
        /*
         * The set OnClickListener sends a byte array containing '/' (the set new password marker)
         * followed by the text input by the user in the newCode text field.
         * This will be processed by the Arduino as a new password and the system will change the password.
         * When a password is set, this becomes the new password to deactivate the alarm.
         * Also displays a popup message on the app confirming the message was sent.
         */
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(newCode.getText().length() == 0)
                    Toast.makeText(getApplicationContext(), "Please Enter New Password", Toast.LENGTH_LONG).show();
                else {
                    String msg = "/" + newCode.getText().toString();
                    byte[] msgBytes = msg.getBytes();

                    try {
                        out.write(msgBytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getApplicationContext(), "Password Set: " + newCode.getText(), Toast.LENGTH_LONG).show();
                }
                //minimizes keyboard upon message being sent
                newCode.getText().clear();
                newCode.onEditorAction(EditorInfo.IME_ACTION_DONE);
            }
        });
    }
}