package com.example.ardalarm;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity{ // implements View.OnClickListener{
    private Button arm, disarm, send, set;
    private EditText password, newCode;
    private BluetoothAdapter bta;
    private BluetoothDevice ard;
    private static final UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static BluetoothSocket socket = null;
    private int attempts;
    private OutputStream out;
    private InputStream in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arm = findViewById(R.id.arm);
        disarm = findViewById(R.id.disarm);
        send = findViewById(R.id.send);
        set = findViewById(R.id.set);
        password = findViewById(R.id.editTextTextPassword);
        newCode = findViewById(R.id.setPassword);

        bta = BluetoothAdapter.getDefaultAdapter();
        ard = bta.getRemoteDevice("00:14:03:05:09:CF"); //contains mac address of arduino bt module

        System.out.println(bta.getBondedDevices()); //test bluetooth connection
        System.out.println(ard.getName());

        attempts = 0;
        do { //attempt to establish socket connection
            try {
                socket = ard.createInsecureRfcommSocketToServiceRecord(uuid);
                socket.connect();

                System.out.println(socket); //test socket connection
                System.out.println(socket.isConnected());
            } catch (IOException e) {
                e.printStackTrace();
            }

            attempts++;
        } while(!socket.isConnected() && attempts < 5);

        try {
            out = socket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        bta.cancelDiscovery();

        arm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    out.write(49);
                }catch (IOException e){
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(), "System Armed", Toast.LENGTH_LONG).show();
            }
        });
        disarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    out.write(48);
                }catch (IOException e){
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(), "System Disarmed", Toast.LENGTH_LONG).show();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(password.getText().length() == 0)
                    Toast.makeText(getApplicationContext(), "Please Enter Password", Toast.LENGTH_LONG).show();
                else {
                    String msg = "*" + password.getText().toString();
                    byte[] msgBytes = msg.getBytes();

                    try {
                        out.write(msgBytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getApplicationContext(), "Password Sent", Toast.LENGTH_LONG).show();
                }
                password.getText().clear();
                password.onEditorAction(EditorInfo.IME_ACTION_DONE);
                newCode.onEditorAction(EditorInfo.IME_ACTION_DONE);
            }
        });
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(newCode.getText().length() == 0)
                    Toast.makeText(getApplicationContext(), "Please Enter New Password", Toast.LENGTH_LONG).show();
                else {
                    String msg = "/" + newCode.getText().toString();
                    byte[] msgBytes = msg.getBytes();

                    try {
                        out.write(msgBytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getApplicationContext(), "Password Set: " + newCode.getText(), Toast.LENGTH_LONG).show();
                }
                newCode.getText().clear();
                newCode.onEditorAction(EditorInfo.IME_ACTION_DONE);
            }
        });
    }
}